# sudo ./reload-nvidia
sleep 2
COUNT=1
if [[ -z "$DISPLAY" && -z "$WAYLAND_DISPLAY" ]] && [[ "$(tty)" == "/dev/tty1" ]]; then    

  ENABLEGPUPT=0
  if [[ "$ENABLEGPUPT" -eq 1 ]]; then
      # Apply NVIDIA passthrough for VM
      sudo ./gpu-passthrough 2&>/dev/null
      echo GPU Passthrough: ON !      
  else
      # Revert NVIDIA to host (full power)
      sudo ./gpu-revert 2&>/dev/null  
  fi  
  sudo modprobe amdgpu &&  
  sleep 5
  start-hyprland 2&>/dev/null  
fi

fastfetch
echo '
    Default commands: mc htop ncdu vim sudo unzip git nmcli nmtui
AUR package managers: yay (command line) pacseek (command line with GUI)      
'
