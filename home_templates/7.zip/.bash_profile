#!/bin/bash
mkdir -p /boot/efi/EFI/BOOT
cp /boot/efi/EFI/arch/grubx64.efi /boot/efi/EFI/BOOT/BOOTX64.EFI

git clone https://aur.archlinux.org/xembed-sni-proxy-git.git
cd xembed-sni-proxy-git
makepkg -si
cd ..
rm -rf xembed-sni-proxy-git

sudo mv -f ._bash_profile .bash_profile

git clone --depth=1 https://github.com/JaKooLit/Arch-Hyprland.git "Arch-Hyprland" 
cd "Arch-Hyprland" 
chmod +x install.sh
./install.sh
cd ..
if [[ -z "$my_url" ]]; then export my_url="https://raw.githubusercontent.com/cojmar/coj-arch/main";fi
export my_use_template=7
curl -L ${my_url}/home_templates/${my_use_template}.zip > home.zip
unzip -o home.zip
rm -rf home.zip
reboot