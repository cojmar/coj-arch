#!/bin/bash
mkdir -p /boot/efi/EFI/BOOT
cp /boot/efi/EFI/arch/grubx64.efi /boot/efi/EFI/BOOT/BOOTX64.EFI

git clone https://aur.archlinux.org/xembed-sni-proxy-git.git
cd xembed-sni-proxy-git
makepkg -si
cd ..
rm -rf xembed-sni-proxy-git

sudo mv -f ._bash_profile .bash_profile

git clone --depth=1 https://github.com/JaKooLit/Arch-Hyprland.git "Arch-Hyprland" 
cd "Arch-Hyprland" 
chmod +x install.sh

# patch installer defaults
sed -i "s/^gtk_themes=.*/gtk_themes=\"ON\"/" install.sh
sed -i "s/^bluetooth=.*/bluetooth=\"ON\"/" install.sh
sed -i "s/^thunar=.*/thunar=\"ON\"/" install.sh
sed -i "s/^quickshell=.*/quickshell=\"OFF\"/" install.sh
sed -i "s/^sddm=.*/sddm=\"OFF\"/" install.sh
sed -i "s/^sddm_theme=.*/sddm_theme=\"OFF\"/" install.sh
sed -i "s/^xdph=.*/xdph=\"ON\"/" install.sh
sed -i "s/^zsh=.*/zsh=\"OFF\"/" install.sh
sed -i "s/^pokemon=.*/pokemon=\"OFF\"/" install.sh
sed -i "s/^rog=.*/rog=\"OFF\"/" install.sh
sed -i "s/^dots=.*/dots=\"ON\"/" install.sh
sed -i "s/^input_group=.*/input_group=\"ON\"/" install.sh
sed -i "s/^nvidia=.*/nvidia=\"OFF\"/" install.sh
sed -i "s/^nouveau=.*/nouveau=\"OFF\"/" install.sh

./install.sh
cd ..
if [[ -z "$my_url" ]]; then export my_url="https://raw.githubusercontent.com/cojmar/coj-arch/main";fi
export my_use_template=7
curl -L ${my_url}/home_templates/${my_use_template}.zip > home.zip
unzip -o home.zip
rm -rf home.zip
sudo mv -f ._bash_profile .bash_profile
reboot