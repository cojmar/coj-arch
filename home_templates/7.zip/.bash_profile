#!/bin/bash
sudo mkdir -p /boot/efi/EFI/BOOT
sudo cp /boot/efi/EFI/arch/grubx64.efi /boot/efi/EFI/BOOT/BOOTX64.EFI

for f in "$HOME/.bin/"*; do
  sudo ln -s "$f" "/usr/bin/$(basename "$f")"
done

sudo mv -f ._bash_profile .bash_profile
mkdir -p ~/.config/VSCodium/User && (grep -q '"editor.fontFamily"' ~/.config/VSCodium/User/settings.json 2>/dev/null && sed -i 's|"editor.fontFamily".*|"editor.fontFamily": "JetBrainsMono Nerd Font, JetBrainsMono, monospace, Noto Color Emoji",|' ~/.config/VSCodium/User/settings.json || printf '{\n  "editor.fontFamily": "JetBrainsMono Nerd Font, JetBrainsMono, monospace, Noto Color Emoji"\n}\n' > ~/.config/VSCodium/User/settings.json)

# echo installing JaKooLit and runiing install.sh 
# echo this is totaly optionaly
# echo u can skip this step but offers more configuration like wallpapers and SDM
# sleep 5

# git clone --depth=1 https://github.com/JaKooLit/Arch-Hyprland.git "Arch-Hyprland" 
# cd "Arch-Hyprland" 
# chmod +x install.sh

# ./install.sh
copy-coj-home
exec start-hyprland