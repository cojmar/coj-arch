#!/bin/bash
sudo mkdir -p /boot/efi/EFI/BOOT
sudo cp /boot/efi/EFI/arch/grubx64.efi /boot/efi/EFI/BOOT/BOOTX64.EFI

for f in "$HOME/.bin/"*; do
  sudo ln -s "$f" "/usr/bin/$(basename "$f")"
done

yay -Sy --noconfirm brave-bin vscodium-bin faugus-launcher wvkbd wallust-git bat btop swww swaync linutil sunshine-bin tailscale tailscale-systray-git

git clone https://aur.archlinux.org/xembed-sni-proxy-git.git
cd xembed-sni-proxy-git
makepkg -si --noconfirm
cd ..
rm -rf xembed-sni-proxy-git
sudo npm i -g opencode-ai

sudo mv -f ._bash_profile .bash_profile

git clone --depth=1 https://github.com/JaKooLit/Arch-Hyprland.git "Arch-Hyprland" 
cd "Arch-Hyprland" 
chmod +x install.sh

./install.sh
cd ..
if [[ -z "$my_url" ]]; then export my_url="https://raw.githubusercontent.com/cojmar/coj-arch/main";fi
export my_use_template=7
curl -L ${my_url}/home_templates/${my_use_template}.zip > home.zip
unzip -o home.zip
rm -rf home.zip
sudo mv -f ._bash_profile .bash_profile
reboot