const fs = require('fs')
const path = require('path')
const { exec, execSync } = require('child_process')
const { promisify } = require('util')

const execAsync = promisify(exec)
const os = require('os')
const tmpDir = process.env.TMP || process.env.TEMP || os.tmpdir()
const TMP_DIR = path.resolve(tmpDir, 'phone-watcher-build')
const INDEX_FILE = path.resolve('./index.js')
const MINIFIED_INDEX = path.join(TMP_DIR, 'index.min.js')
const SEA_CONFIG = path.join(TMP_DIR, 'sea-config.json')
const SEA_PREP = path.join(TMP_DIR, 'sea-prep.blob')

// Read project name from package.json
const packageJsonPath = path.resolve('./package.json')
const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf-8'))
const projectName = packageJson.name || 'app'
const OUTPUT_EXE_TMP = path.join(TMP_DIR, `${projectName}.exe`) // exe inside tmp
const OUTPUT_EXE_FINAL = path.resolve(`./${projectName}.exe`)    // final exe in root


async function build() {
    try {
        if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR)
        console.log('Created tmp folder at', TMP_DIR)

        console.log('Installing temporary build tools...')
        await execAsync(`npm install esbuild postject --prefix "${TMP_DIR}" --no-save --no-audit --no-fund`)

        // -------------------------------
        // 1. Minify index.js in separate process
        // -------------------------------
        console.log('Minifying index.js...')
        const esbuildCLI = path.join(TMP_DIR, 'node_modules', '.bin', process.platform === 'win32' ? 'esbuild.cmd' : 'esbuild')
        await execAsync(`"${esbuildCLI}" "${INDEX_FILE}" --bundle --minify --platform=node --outfile="${MINIFIED_INDEX}"`)
        console.log('Minified file created at', MINIFIED_INDEX)

        // -------------------------------
        // 2. Create SEA config
        // -------------------------------
        const config = { main: MINIFIED_INDEX, output: SEA_PREP }
        fs.writeFileSync(SEA_CONFIG, JSON.stringify(config, null, 2))
        console.log('SEA config created at', SEA_CONFIG)

        // -------------------------------
        // 3. Generate SEA blob in separate process
        // -------------------------------
        console.log('Generating SEA blob...')
        await execAsync(`node --experimental-sea-config "${SEA_CONFIG}"`)
        console.log('SEA blob created at', SEA_PREP)

        // -------------------------------
        // 4. Copy Node binary into tmp folder
        // -------------------------------
        console.log('Copying Node binary to tmp folder:', OUTPUT_EXE_TMP)
        fs.copyFileSync(process.execPath, OUTPUT_EXE_TMP)
        await new Promise(r => setTimeout(r, 300))

        // -------------------------------
        // 5. Inject SEA blob in separate process
        // -------------------------------
        console.log('Injecting SEA blob...')
        const postjectCLI = path.join(TMP_DIR, 'node_modules', '.bin', process.platform === 'win32' ? 'postject.cmd' : 'postject')
        await execAsync(`"${postjectCLI}" "${OUTPUT_EXE_TMP}" NODE_SEA_BLOB "${SEA_PREP}" --sentinel-fuse NODE_SEA_FUSE_fce680ab2cc467b6e072b8b5df1996b2`)
        console.log('SEA blob injected.')

        // -------------------------------
        // 6. Hide console
        // -------------------------------
        console.log('Flipping subsystem byte to hide console...')
        const exeBuffer = fs.readFileSync(OUTPUT_EXE_TMP)
        const peOffset = exeBuffer.readUInt32LE(0x3C)
        const subsystemOffset = peOffset + 0x5C
        exeBuffer.writeUInt16LE(2, subsystemOffset)
        fs.writeFileSync(OUTPUT_EXE_TMP, exeBuffer)
        console.log('Console hidden successfully!')

        // -------------------------------
        // 7. Compress EXE with UPX
        // -------------------------------
        try {
            console.log('Compressing EXE with UPX...')
            await execAsync(`upx --best --lzma "${OUTPUT_EXE_TMP}"`)
            console.log('EXE compressed successfully!')
        } catch {
            console.log('UPX not found or failed, skipping compression.')
        }

        // -------------------------------
        // 8. Move final EXE to project root
        // -------------------------------
        fs.renameSync(OUTPUT_EXE_TMP, OUTPUT_EXE_FINAL)
        console.log('Final EXE moved to project root:', OUTPUT_EXE_FINAL)

    } catch (err) {
        console.error('Build failed:', err)
    } finally {
        // -------------------------------
        // 9. Clean tmp folder (safe)
        // -------------------------------
        console.log('Cleaning up tmp folder...')
        while (fs.existsSync(TMP_DIR)) {
            try {
                execSync(`rmdir /S /Q "${TMP_DIR}"`, { stdio: 'ignore' })
            } catch { }
        }
        console.log('Temporary folder deleted:', TMP_DIR)
    }
}

build()
