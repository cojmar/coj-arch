const { exec } = require('child_process')
const path = require('path')
const https = require('https')
const fs = require('fs')
const os = require('os')
const tmpDir = process.env.TMP || process.env.TEMP || os.tmpdir()
const isWindows = process.platform === 'win32'

class download {
    constructor() {
        this.baseDir = tmpDir
        this.scrcpyDir = path.join(this.baseDir, 'scrcpy')
        this.zipPath = path.join(this.baseDir, 'scrcpy.zip')
        this.init()
    }

    async init() {
        if (!isWindows) {
            console.log('[INFO] Linux detected, skipping scrcpy download')
            return new main(false)
        }

        if (!fs.existsSync(this.scrcpyDir)) {
            console.log('[INFO] scrcpy folder not found, downloading latest release...')
            try {
                const latestTag = await this.getLatestReleaseTag()
                const url = `https://github.com/Genymobile/scrcpy/releases/download/${latestTag}/scrcpy-win64-${latestTag}.zip`
                console.log('[INFO] Downloading:', url)

                await this.downloadFile(url, this.zipPath)
                console.log('[INFO] Download complete, extracting...')

                await this.extractZip(this.zipPath, this.scrcpyDir)
                console.log('[INFO] Extraction complete')

                fs.unlinkSync(this.zipPath)
                console.log('[INFO] Temporary zip removed')
            } catch (err) {
                console.error('[ERROR] Failed to set up scrcpy:', err)
            }
        } else {
            console.log('[INFO] scrcpy folder already exists')
        }
        new main(true)
    }

    getLatestReleaseTag() {
        return new Promise((resolve, reject) => {
            https.get('https://api.github.com/repos/Genymobile/scrcpy/releases/latest', {
                headers: { 'User-Agent': 'Node.js' }
            }, (res) => {
                if (res.statusCode !== 200) return reject(new Error(`Failed to fetch release info: ${res.statusCode}`))
                let data = ''
                res.on('data', chunk => data += chunk)
                res.on('end', () => {
                    try {
                        const release = JSON.parse(data)
                        resolve(release.tag_name)
                    } catch (err) {
                        reject(new Error('Failed to parse release info'))
                    }
                })
            }).on('error', reject)
        })
    }

    downloadFile(url, dest) {
        return new Promise((resolve, reject) => {
            const file = fs.createWriteStream(dest)
            const request = (u) => {
                https.get(u, (response) => {
                    if ([301, 302, 303, 307, 308].includes(response.statusCode)) {
                        return request(response.headers.location)
                    }
                    if (response.statusCode !== 200) {
                        return reject(new Error(`Failed to download file: ${response.statusCode}`))
                    }
                    response.pipe(file)
                    file.on('finish', () => file.close(resolve))
                    file.on('error', err => {
                        fs.unlink(dest, () => reject(err))
                    })
                }).on('error', reject)
            }
            request(url)
        })
    }

    async extractZip(zipPath, outPath) {
        return new Promise((resolve, reject) => {
            console.log('[INFO] Extracting zip using PowerShell...')
            const cmd = `powershell -Command "Expand-Archive -Path '${zipPath}' -DestinationPath '${outPath}' -Force"`
            exec(cmd, (err) => {
                if (err) return reject(err)
                const entries = fs.readdirSync(outPath, { withFileTypes: true })
                const topFolder = entries.find(e => e.isDirectory())
                if (!topFolder) return resolve()
                const topFolderPath = path.join(outPath, topFolder.name)
                const items = fs.readdirSync(topFolderPath)
                for (const item of items) {
                    const oldPath = path.join(topFolderPath, item)
                    const newPath = path.join(outPath, item)
                    fs.renameSync(oldPath, newPath)
                }
                fs.rmdirSync(topFolderPath)
                resolve()
            })
        })
    }
}

class main {
    constructor(isWindowsEnv) {
        this.defaultPath = isWindowsEnv ? path.join(tmpDir, "scrcpy") :""
        this.scrcpyVbs = isWindowsEnv ? path.join(this.defaultPath, "scrcpy-noconsole.vbs"):"scrcpy"
        this.adbPath = isWindowsEnv ? path.join(this.defaultPath, "adb.exe") : "adb"
        this.scrcpyCmd = isWindowsEnv ? `"${this.scrcpyVbs}"` : "scrcpy"
        this.connected = []
        this.watchInterval = 1000
        this.ensureSingleInstance()
        this.watcher()
    }

    ensureSingleInstance() {
        const lockFile = path.join(this.defaultPath, '.app.pid')
        if (fs.existsSync(lockFile)) {
            try {
                const oldPid = parseInt(fs.readFileSync(lockFile, 'utf-8'), 10)
                if (!isNaN(oldPid) && oldPid > 0) {
                    try {
                        process.kill(oldPid)
                        console.log(`[INFO] Killed previous instance (PID ${oldPid})`)
                    } catch { }
                }
            } catch { }
        }

        fs.writeFileSync(lockFile, process.pid.toString(), 'utf-8')
        const cleanup = () => {
            try { fs.unlinkSync(lockFile) } catch { }
        }
        process.on('exit', cleanup)
        process.on('SIGINT', () => process.exit(0))
        process.on('SIGTERM', () => process.exit(0))
    }

    async watcher() {
        const devices = await this.getDevices()
        for (const device of devices) {
            if (!this.connected.includes(device)) {
                console.log(`[INFO] New device connected: ${device}`)
                this.scrcpy(device)
            }
        }
        for (const device of this.connected) {
            if (!devices.includes(device)) {
                console.log(`[INFO] Device disconnected: ${device}`)
            }
        }
        this.connected = devices
        setTimeout(() => this.watcher(), this.watchInterval)
    }

    async getDevices() {
        const output = await new Promise(resolve => {
            try {
                exec(`${this.adbPath} devices`, { windowsHide: true }, (error, stdout, stderr) => {
                    if (error || stderr) return resolve(false)
                    resolve(stdout)
                })
            } catch {
                resolve(false)
            }
        })
        if (!output) return []
        const lines = output.trim().split('\n').slice(1)
        return lines.map(l => l.trim().split('\t')[0]).filter(Boolean)
    }

    scrcpy(device) {
        const cmd = isWindows
            ? `start "" ${this.scrcpyCmd} --serial ${device} --always-on-top --turn-screen-off --no-audio --max-size 1024`
            : `${this.scrcpyCmd} --serial ${device} --always-on-top --turn-screen-off --no-audio --max-size 1024 &`
        exec(cmd, { cwd: this.defaultPath }, () => { })
    }
}


new download()
