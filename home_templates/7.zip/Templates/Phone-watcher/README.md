# Purpose of the Project

- Connect multiple Android devices to a Windows PC via USB debugging
- No APK needed on the phone — just enable USB debugging and trust the computer
- Automatically detects when Android devices connect and opens remote control for them
- Single instance — reopening creates new windows for all connected devices
- Slim and portable — no installation required; all extra files are temporary
- Can be built into a portable executable
- Can run on startup via a shortcut: type `shell:startup` in **Win + R**, then place a shortcut to the app

This project aims to streamline device management and provide a lightweight, hassle-free remote control solution for multiple Android devices on Windows.

# Usage

- Clone the repository:  
  ```bash
  git clone https://github.com/cojmar/Phone-watcher.git
  ```
- Run the application:  
  ```bash
  npm start
  ```
  or  
  ```bash
  node index
  ```
- Build the portable executable:  
  ```bash
  npm run build
  ```
  or  
  ```bash
  node build
  ```
Alternatively, download the prebuilt version from the [Releases page](https://github.com/cojmar/Phone-watcher/releases)
