-- Rebuilt from the original Hyprland .conf; generated conversion, review before use.
---@module 'hl'

local function ex(s)
    return (tostring(s):gsub("%$([%w_]+)", function(k)
        if k == "HOME" then return os.getenv("HOME") or "" end
        local v = _G.HYPR_VARS and _G.HYPR_VARS[k]
        return v ~= nil and tostring(v) or "$" .. k
    end))
end
_G.HYPR_VARS = _G.HYPR_VARS or {}

hl.on("hyprland.start", function() hl.exec_cmd(ex("$HOME/.config/hypr/UserScripts/restore_hypr_session.sh")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("lms server start")) end)
