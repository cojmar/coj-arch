-- Rebuilt from the original Hyprland .conf; generated conversion, review before use.
---@module 'hl'

local function ex(s)
    return (tostring(s):gsub("%$([%w_]+)", function(k)
        if k == "HOME" then return os.getenv("HOME") or "" end
        local v = _G.HYPR_VARS and _G.HYPR_VARS[k]
        return v ~= nil and tostring(v) or "$" .. k
    end))
end
_G.HYPR_VARS = _G.HYPR_VARS or {}

dofile((os.getenv("HOME") or "") .. "/.config/hypr/wallust/wallust-hyprland.lua")
hl.config({ general = {
    ["border_size"] = 1,
    ["gaps_in"] = 1,
    ["gaps_out"] = 1,
    ["col.active_border"] = ex("$color12"),
    ["col.inactive_border"] = ex("$color10"),
} })
hl.config({ decoration = {
    ["rounding"] = 0,
    ["active_opacity"] = 1.0,
    ["inactive_opacity"] = 1,
    ["fullscreen_opacity"] = 1.0,
    ["dim_inactive"] = false,
    ["dim_strength"] = 0.1,
    ["dim_special"] = 0.8,
    ["shadow"] = {
        ["enabled"] = false,
        ["range"] = 3,
        ["render_power"] = 1,
        ["color"] = ex("$color12"),
        ["color_inactive"] = ex("$color10"),
    },
} })
-- hl.config({ blur = {
--     ["enabled"] = false,
--     ["size"] = 6,
--     ["passes"] = 3,
--     ["new_optimizations"] = true,
--     ["xray"] = true,
--     ["ignore_opacity"] = true,
--     ["special"] = true,
--     ["popups"] = true,
-- } })
hl.config({ group = {
    ["col.border_active"] = ex("$color15"),
    ["groupbar"] = {
        ["col.active"] = ex("$color0"),
    },
} })
