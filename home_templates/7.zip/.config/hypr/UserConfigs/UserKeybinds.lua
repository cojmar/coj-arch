-- Rebuilt from the original Hyprland .conf; generated conversion, review before use.
---@module 'hl'

local function ex(s)
    return (tostring(s):gsub("%$([%w_]+)", function(k)
        if k == "HOME" then return os.getenv("HOME") or "" end
        local v = _G.HYPR_VARS and _G.HYPR_VARS[k]
        return v ~= nil and tostring(v) or "$" .. k
    end))
end
_G.HYPR_VARS = _G.HYPR_VARS or {}

_G.HYPR_VARS["mainMod"] = ex("SUPER")
_G.HYPR_VARS["scriptsDir"] = ex("$HOME/.config/hypr/scripts")
_G.HYPR_VARS["UserScripts"] = ex("$HOME/.config/hypr/UserScripts")
_G.HYPR_VARS["UserConfigs"] = ex("$HOME/.config/hypr/UserConfigs")
hl.bind(ex("SUPER + W"), hl.dsp.exec_cmd(ex("xdg-open \"https://\"")))
hl.bind(ex("SUPER + Z"), hl.dsp.exec_cmd(ex("discord")))
hl.bind(ex("SUPER + SHIFT + Z"), hl.dsp.exec_cmd(ex("wdiscord")))
hl.bind(ex("SUPER + C"), hl.dsp.exec_cmd(ex("vscodium")))
hl.bind(ex("SUPER + X"), hl.dsp.exec_cmd(ex("battlenet2")))
hl.bind(ex("SUPER + V"), hl.dsp.exec_cmd(ex("$HOME/.config/hypr/UserScripts/ocr-capture")))
