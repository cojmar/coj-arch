-- Rebuilt from the original Hyprland .conf; generated conversion, review before use.
---@module 'hl'

local function ex(s)
    return (tostring(s):gsub("%$([%w_]+)", function(k)
        if k == "HOME" then return os.getenv("HOME") or "" end
        local v = _G.HYPR_VARS and _G.HYPR_VARS[k]
        return v ~= nil and tostring(v) or "$" .. k
    end))
end
_G.HYPR_VARS = _G.HYPR_VARS or {}

_G.HYPR_VARS["mainMod"] = ex("SUPER")
_G.HYPR_VARS["scriptsDir"] = ex("$HOME/.config/hypr/scripts")
_G.HYPR_VARS["UserConfigs"] = ex("$HOME/.config/hypr/UserConfigs")
