-- Rebuilt from the original Hyprland .conf; generated conversion, review before use.
---@module 'hl'

local function ex(s)
    return (tostring(s):gsub("%$([%w_]+)", function(k)
        if k == "HOME" then return os.getenv("HOME") or "" end
        local v = _G.HYPR_VARS and _G.HYPR_VARS[k]
        return v ~= nil and tostring(v) or "$" .. k
    end))
end
_G.HYPR_VARS = _G.HYPR_VARS or {}

_G.HYPR_VARS["mainMod"] = ex("SUPER")
_G.HYPR_VARS["scriptsDir"] = ex("$HOME/.config/hypr/scripts")
_G.HYPR_VARS["UserConfigs"] = ex("$HOME/.config/hypr/UserConfigs")
_G.HYPR_VARS["Touchpad_Device"] = ex("asue1209:00-04f3:319f-touchpad")
hl.bind(ex("XF86KbdBrightnessDown"), hl.dsp.exec_cmd(ex("$HOME/.config/hypr/scripts/BrightnessKbd.sh --dec")), { repeating = true })
hl.bind(ex("XF86KbdBrightnessUp"), hl.dsp.exec_cmd(ex("$HOME/.config/hypr/scripts/BrightnessKbd.sh --inc")), { repeating = true })
hl.bind(ex("XF86MonBrightnessDown"), hl.dsp.exec_cmd(ex("$HOME/.config/hypr/scripts/Brightness.sh --dec")), { repeating = true })
hl.bind(ex("XF86MonBrightnessUp"), hl.dsp.exec_cmd(ex("$HOME/.config/hypr/scripts/Brightness.sh --inc")), { repeating = true })
_G.HYPR_VARS["TOUCHPAD_ENABLED"] = true
hl.device({
    name = "asue1209:00-04f3:319f-touchpad",
    enabled = true,
})
