-- Rebuilt from the original Hyprland .conf; generated conversion, review before use.
---@module 'hl'

local function ex(s)
    return (tostring(s):gsub("%$([%w_]+)", function(k)
        if k == "HOME" then return os.getenv("HOME") or "" end
        local v = _G.HYPR_VARS and _G.HYPR_VARS[k]
        return v ~= nil and tostring(v) or "$" .. k
    end))
end
_G.HYPR_VARS = _G.HYPR_VARS or {}

_G.HYPR_VARS["scriptsDir"] = ex("$HOME/.config/hypr/scripts")
_G.HYPR_VARS["UserScripts"] = ex("$HOME/.config/hypr/UserScripts")
_G.HYPR_VARS["lock"] = ex("$scriptsDir/LockScreen.sh")
_G.HYPR_VARS["awwwRandom"] = ex("$UserScripts/WallpaperAutoChange.sh")
_G.HYPR_VARS["livewallpaper"] = ""
_G.HYPR_VARS["wallDIR"] = ex("$HOME/Pictures/wallpapers")
hl.on("hyprland.start", function() hl.exec_cmd(ex("awww-daemon --format xrgb")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("dbus-update-activation-environment --systemd WAYLAND_DISPLAY XDG_CURRENT_DESKTOP")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("systemctl --user import-environment WAYLAND_DISPLAY XDG_CURRENT_DESKTOP")) end)
-- hl.on("hyprland.start", function() hl.exec_cmd(ex("$HOME/.config/hypr/scripts/Dropterminal.sh kitty &")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("$scriptsDir/Polkit.sh")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("nm-applet --indicator")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("qs -c overview")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("hypridle")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("$scriptsDir/Hyprsunset.sh init")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("wl-paste --type text --watch cliphist store")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("wl-paste --type image --watch cliphist store")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("$scriptsDir/PortalHyprland.sh")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("blueman-applet")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("$scriptsDir/KeybindsLayoutInit.sh")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("xembedsniproxy")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("sunshine")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("node $HOME/Templates/Phone-watcher/index.js")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("tailscale-systray")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("grep -q '^[[:space:]]*ENABLEGPUPT=1' ~/.bash_profile && notify-send \"GPU ISOLATED\" || notify-send \"GPU FULL POWER\"")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("waybar")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("swaync")) end)
hl.on("hyprland.start", function() hl.exec_cmd(ex("sleep 5 && hyprctl reload")) end)
