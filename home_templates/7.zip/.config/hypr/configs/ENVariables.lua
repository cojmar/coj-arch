-- Rebuilt from the original Hyprland .conf; generated conversion, review before use.
---@module 'hl'

local function ex(s)
    return (tostring(s):gsub("%$([%w_]+)", function(k)
        if k == "HOME" then return os.getenv("HOME") or "" end
        local v = _G.HYPR_VARS and _G.HYPR_VARS[k]
        return v ~= nil and tostring(v) or "$" .. k
    end))
end
_G.HYPR_VARS = _G.HYPR_VARS or {}

hl.env("DOTS_VERSION", ex("2.3.20"))
hl.env("GDK_BACKEND", ex("wayland,x11,*"))
hl.env("QT_QPA_PLATFORM", ex("wayland;xcb"))
hl.env("CLUTTER_BACKEND", ex("wayland"))
hl.env("XDG_CURRENT_DESKTOP", ex("Hyprland"))
hl.env("XDG_SESSION_DESKTOP", ex("Hyprland"))
hl.env("XDG_SESSION_TYPE", ex("wayland"))
hl.env("QT_AUTO_SCREEN_SCALE_FACTOR", ex("1"))
hl.env("QT_WAYLAND_DISABLE_WINDOWDECORATION", ex("1"))
hl.env("QT_QPA_PLATFORMTHEME", ex("qt5ct"))
hl.env("QT_QPA_PLATFORMTHEME", ex("qt6ct"))
hl.env("QT_QUICK_CONTROLS_STYLE", ex("org.hyprland.style"))
hl.env("GDK_SCALE", ex("1"))
hl.env("QT_SCALE_FACTOR", ex("1"))
hl.env("HYPRCURSOR_THEME", ex("Bibata-Modern-Ice"))
hl.env("HYPRCURSOR_SIZE", ex("24"))
hl.env("XCURSOR_THEME", ex("Bibata-Modern-Ice"))
hl.env("XCURSOR_SIZE", ex("24"))
hl.env("XCURSOR_PATH", ex("$HOME/.icons:/usr/share/icons:/usr/share/pixmaps"))
hl.env("OZONE_PLATFORM_HINT", ex("auto"))
hl.env("MOZ_ENABLE_WAYLAND", ex("1"))
hl.env("ELECTRON_OZONE_PLATFORM_HINT", ex("auto"))
hl.env("LIBVA_DRIVER_NAME", ex("nvidia"))
hl.env("__GLX_VENDOR_LIBRARY_NAME", ex("nvidia"))
hl.env("NVD_BACKEND", ex("direct"))
hl.env("GSK_RENDERER", ex("ngl"))
hl.env("WLR_NO_HARDWARE_CURSORS", ex("1"))
hl.env("WLR_DRM_NO_ATOMIC", ex("1"))
