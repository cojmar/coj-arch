-- Rebuilt from the original Hyprland .conf; generated conversion, review before use.
---@module 'hl'

local function ex(s)
    return (tostring(s):gsub("%$([%w_]+)", function(k)
        if k == "HOME" then return os.getenv("HOME") or "" end
        local v = _G.HYPR_VARS and _G.HYPR_VARS[k]
        return v ~= nil and tostring(v) or "$" .. k
    end))
end
_G.HYPR_VARS = _G.HYPR_VARS or {}

_G.HYPR_VARS["scriptsDir"] = ex("$HOME/.config/hypr/scripts")
hl.config({ dwindle = {
    ["preserve_split"] = true,
    ["special_scale_factor"] = 0.8,
} })
hl.config({ master = {
    ["new_status"] = ex("master"),
    ["new_on_top"] = 1,
    ["mfact"] = 0.5,
} })
hl.config({ general = {
    ["resize_on_border"] = true,
    ["layout"] = ex("dwindle"),
} })
hl.config({ input = {
    ["kb_layout"] = ex("us"),
    ["kb_variant"] = "",
    ["kb_model"] = "",
    ["kb_options"] = "",
    ["kb_rules"] = "",
    ["repeat_rate"] = 50,
    ["repeat_delay"] = 300,
    ["sensitivity"] = 0,
    ["numlock_by_default"] = true,
    ["left_handed"] = false,
    ["follow_mouse"] = 1,
    ["float_switch_override_focus"] = false,
    ["touchpad"] = {
        ["disable_while_typing"] = true,
        ["natural_scroll"] = true,
        ["clickfinger_behavior"] = false,
        ["middle_button_emulation"] = false,
        ["tap_to_click"] = true,
        ["drag_lock"] = false,
    },
} })
-- hl.config({ touchdevice = {
--     ["enabled"] = true,
-- } })
-- hl.config({ tablet = {
--     ["transform"] = 0,
--     ["left_handed"] = 0,
-- } })
hl.config({ gestures = {
    ["workspace_swipe_distance"] = 500,
    ["workspace_swipe_invert"] = true,
    ["workspace_swipe_min_speed_to_force"] = 30,
    ["workspace_swipe_cancel_ratio"] = 0.5,
    ["workspace_swipe_create_new"] = true,
    ["workspace_swipe_forever"] = true,
} })
hl.config({ misc = {
    ["disable_hyprland_logo"] = true,
    ["disable_splash_rendering"] = true,
    ["vrr"] = 2,
    ["mouse_move_enables_dpms"] = true,
    ["enable_swallow"] = false,
    ["swallow_regex"] = ex("^(kitty)$"),
    ["focus_on_activate"] = false,
    ["initial_workspace_tracking"] = 0,
    ["middle_click_paste"] = false,
    ["enable_anr_dialog"] = true,
    ["anr_missed_pings"] = 15,
    ["allow_session_lock_restore"] = true,
    ["on_focus_under_fullscreen"] = 1,
} })
hl.config({ binds = {
    ["workspace_back_and_forth"] = true,
    ["allow_workspace_cycles"] = true,
    ["pass_mouse_when_bound"] = false,
} })
hl.config({ xwayland = {
    ["enabled"] = true,
    ["force_zero_scaling"] = true,
} })
hl.config({ render = {
    ["direct_scanout"] = 0,
} })
hl.config({ cursor = {
    ["sync_gsettings_theme"] = true,
    ["no_hardware_cursors"] = 0,
    ["enable_hyprcursor"] = false,
    ["warp_on_change_workspace"] = 2,
    ["no_warps"] = true,
} })
hl.config({ debug = {
    ["vfr"] = true,
} })
