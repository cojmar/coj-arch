-- Rebuilt from the original Hyprland .conf; generated conversion, review before use.
---@module 'hl'

local function ex(s)
    return (tostring(s):gsub("%$([%w_]+)", function(k)
        if k == "HOME" then return os.getenv("HOME") or "" end
        local v = _G.HYPR_VARS and _G.HYPR_VARS[k]
        return v ~= nil and tostring(v) or "$" .. k
    end))
end
_G.HYPR_VARS = _G.HYPR_VARS or {}

hl.curve("wind", { type = "bezier", points = { { 0.05, 0.9 }, { 0.1, 1.05 } } })
hl.curve("winIn", { type = "bezier", points = { { 0.1, 1.1 }, { 0.1, 1.1 } } })
hl.curve("winOut", { type = "bezier", points = { { 0.3, -0.3 }, { 0, 1 } } })
hl.curve("liner", { type = "bezier", points = { { 1, 1 }, { 1, 1 } } })
hl.curve("md3_standard", { type = "bezier", points = { { 0.2, 0 }, { 0, 1 } } })
hl.curve("md3_decel", { type = "bezier", points = { { 0.05, 0.7 }, { 0.1, 1 } } })
hl.curve("md3_accel", { type = "bezier", points = { { 0.3, 0 }, { 0.8, 0.15 } } })
hl.curve("overshot", { type = "bezier", points = { { 0.05, 0.9 }, { 0.1, 1.1 } } })
hl.curve("crazyshot", { type = "bezier", points = { { 0.1, 1.5 }, { 0.76, 0.92 } } })
hl.curve("hyprnostretch", { type = "bezier", points = { { 0.05, 0.9 }, { 0.1, 1.0 } } })
hl.curve("menu_decel", { type = "bezier", points = { { 0.1, 1 }, { 0, 1 } } })
hl.curve("menu_accel", { type = "bezier", points = { { 0.38, 0.04 }, { 1, 0.07 } } })
hl.curve("easeInOutCirc", { type = "bezier", points = { { 0.85, 0 }, { 0.15, 1 } } })
hl.curve("easeOutCirc", { type = "bezier", points = { { 0, 0.55 }, { 0.45, 1 } } })
hl.curve("easeOutExpo", { type = "bezier", points = { { 0.16, 1 }, { 0.3, 1 } } })
hl.curve("softAcDecel", { type = "bezier", points = { { 0.26, 0.26 }, { 0.15, 1 } } })
hl.curve("md2", { type = "bezier", points = { { 0.4, 0 }, { 0.2, 1 } } })
hl.animation({ leaf = "border", enabled = true, speed = 1, curve = "liner" })
hl.animation({ leaf = "borderangle", enabled = true, speed = 30, curve = "liner", style = "once" })
hl.animation({ leaf = "windows", enabled = true, speed = 6, curve = "wind", style = "slide" })
hl.animation({ leaf = "windowsIn", enabled = true, speed = 6, curve = "winIn", style = "slide" })
hl.animation({ leaf = "windowsOut", enabled = true, speed = 5, curve = "winOut", style = "slide" })
hl.animation({ leaf = "windowsMove", enabled = true, speed = 5, curve = "wind", style = "slide" })
hl.animation({ leaf = "fade", enabled = true, speed = 3, curve = "md3_decel" })
hl.animation({ leaf = "layersIn", enabled = true, speed = 3, curve = "menu_decel", style = "slide" })
hl.animation({ leaf = "layersOut", enabled = true, speed = 1.6, curve = "menu_accel" })
hl.animation({ leaf = "fadeLayersIn", enabled = true, speed = 2, curve = "menu_decel" })
hl.animation({ leaf = "fadeLayersOut", enabled = true, speed = 4.5, curve = "menu_accel" })
hl.animation({ leaf = "workspaces", enabled = true, speed = 7, curve = "menu_decel", style = "slide" })
hl.animation({ leaf = "workspaces", enabled = true, speed = 5, curve = "wind" })
hl.animation({ leaf = "specialWorkspace", enabled = true, speed = 3, curve = "md3_decel", style = "slidefadevert 15%" })
hl.animation({ leaf = "specialWorkspace", enabled = true, speed = 3, curve = "md3_decel", style = "slidevert" })
