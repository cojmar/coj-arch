-- Rebuilt from the original Hyprland .conf; generated conversion, review before use.
---@module 'hl'

local function ex(s)
    return (tostring(s):gsub("%$([%w_]+)", function(k)
        if k == "HOME" then return os.getenv("HOME") or "" end
        local v = _G.HYPR_VARS and _G.HYPR_VARS[k]
        return v ~= nil and tostring(v) or "$" .. k
    end))
end
_G.HYPR_VARS = _G.HYPR_VARS or {}

hl.curve("quart", { type = "bezier", points = { { 0.25, 1 }, { 0.5, 1 } } })
hl.animation({ leaf = "windows", enabled = true, speed = 6, curve = "quart", style = "slide" })
hl.animation({ leaf = "border", enabled = true, speed = 6, curve = "quart" })
hl.animation({ leaf = "borderangle", enabled = true, speed = 6, curve = "quart" })
hl.animation({ leaf = "fade", enabled = true, speed = 6, curve = "quart" })
hl.animation({ leaf = "workspaces", enabled = true, speed = 6, curve = "quart" })
