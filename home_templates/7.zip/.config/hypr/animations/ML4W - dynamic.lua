-- Rebuilt from the original Hyprland .conf; generated conversion, review before use.
---@module 'hl'

local function ex(s)
    return (tostring(s):gsub("%$([%w_]+)", function(k)
        if k == "HOME" then return os.getenv("HOME") or "" end
        local v = _G.HYPR_VARS and _G.HYPR_VARS[k]
        return v ~= nil and tostring(v) or "$" .. k
    end))
end
_G.HYPR_VARS = _G.HYPR_VARS or {}

hl.curve("wind", { type = "bezier", points = { { 0.05, 0.9 }, { 0.1, 1.05 } } })
hl.curve("winIn", { type = "bezier", points = { { 0.1, 1.1 }, { 0.1, 1.1 } } })
hl.curve("winOut", { type = "bezier", points = { { 0.3, -0.3 }, { 0, 1 } } })
hl.curve("liner", { type = "bezier", points = { { 1, 1 }, { 1, 1 } } })
hl.animation({ leaf = "windows", enabled = true, speed = 6, curve = "wind", style = "slide" })
hl.animation({ leaf = "windowsIn", enabled = true, speed = 6, curve = "winIn", style = "slide" })
hl.animation({ leaf = "windowsOut", enabled = true, speed = 5, curve = "winOut", style = "slide" })
hl.animation({ leaf = "windowsMove", enabled = true, speed = 5, curve = "wind", style = "slide" })
hl.animation({ leaf = "border", enabled = true, speed = 1, curve = "liner" })
hl.animation({ leaf = "borderangle", enabled = true, speed = 30, curve = "liner", style = "loop" })
hl.animation({ leaf = "fade", enabled = true, speed = 10, curve = "default" })
hl.animation({ leaf = "workspaces", enabled = true, speed = 5, curve = "wind" })
