-- Rebuilt from the original Hyprland .conf; generated conversion, review before use.
---@module 'hl'

local function ex(s)
    return (tostring(s):gsub("%$([%w_]+)", function(k)
        if k == "HOME" then return os.getenv("HOME") or "" end
        local v = _G.HYPR_VARS and _G.HYPR_VARS[k]
        return v ~= nil and tostring(v) or "$" .. k
    end))
end
_G.HYPR_VARS = _G.HYPR_VARS or {}

_G.HYPR_VARS["background"] = ex("rgb(2A2C2D)")
_G.HYPR_VARS["foreground"] = ex("rgb(E1DFDB)")
_G.HYPR_VARS["color0"] = ex("rgb(4F5152)")
_G.HYPR_VARS["color1"] = ex("rgb(5C605D)")
_G.HYPR_VARS["color2"] = ex("rgb(7F7A73)")
_G.HYPR_VARS["color3"] = ex("rgb(7F7A73)")
_G.HYPR_VARS["color4"] = ex("rgb(7F7A73)")
_G.HYPR_VARS["color5"] = ex("rgb(7F7A73)")
_G.HYPR_VARS["color6"] = ex("rgb(7F7A73)")
_G.HYPR_VARS["color7"] = ex("rgb(CCC9C4)")
_G.HYPR_VARS["color8"] = ex("rgb(8E8C89)")
_G.HYPR_VARS["color9"] = ex("rgb(7A807C)")
_G.HYPR_VARS["color10"] = ex("rgb(A9A399)")
_G.HYPR_VARS["color11"] = ex("rgb(A9A399)")
_G.HYPR_VARS["color12"] = ex("rgb(A9A399)")
_G.HYPR_VARS["color13"] = ex("rgb(A9A399)")
_G.HYPR_VARS["color14"] = ex("rgb(A9A399)")
_G.HYPR_VARS["color15"] = ex("rgb(CCC9C4)")
