-- Rebuilt from the original Hyprland .conf; generated conversion, review before use.
---@module 'hl'

local function ex(s)
    return (tostring(s):gsub("%$([%w_]+)", function(k)
        if k == "HOME" then return os.getenv("HOME") or "" end
        local v = _G.HYPR_VARS and _G.HYPR_VARS[k]
        return v ~= nil and tostring(v) or "$" .. k
    end))
end
_G.HYPR_VARS = _G.HYPR_VARS or {}

hl.monitor({ output = "HDMI-A-2", mode = "1920x1080@60.0", position = "3565x0", scale = 1.0 })
hl.monitor({ output = "HDMI-A-1", mode = "1920x1080@60.0", position = "1645x0", scale = 1 })
