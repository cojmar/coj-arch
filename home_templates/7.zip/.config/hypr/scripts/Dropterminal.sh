#!/usr/bin/env bash

CLASS="hyprterm"
HIDE_WS="special:hyprterm"
WIDTH=900
HEIGHT=600

ADDR=$(hyprctl clients -j | jq -r --arg c "$CLASS" \
  '[.[] | select(.class == $c)] | first | .address // empty')

if [[ -z "$ADDR" ]]; then
    kitty --class="$CLASS" &
    # Wait for window to appear
    for i in {1..50}; do
        ADDR=$(hyprctl clients -j | jq -r --arg c "$CLASS" \
          '[.[] | select(.class == $c)] | first | .address // empty')
        [[ -n "$ADDR" ]] && break
        sleep 0.1
    done
    sleep 0.3
    # 1. Kill maximize/fullscreen state
    hyprctl eval "hl.dispatch(hl.dsp.window.fullscreen({ mode = 'maximized', action = 'unset', window = 'address:$ADDR' }))"
    # 2. Float
    hyprctl eval "hl.dispatch(hl.dsp.window.float({ action = 'set', window = 'address:$ADDR' }))"
    # 3. Resize (relative must be boolean false)
    hyprctl eval "hl.dispatch(hl.dsp.window.resize({ x = $WIDTH, y = $HEIGHT, relative = false, window = 'address:$ADDR' }))"
    # 4. Center
    hyprctl eval "hl.dispatch(hl.dsp.window.center({ window = 'address:$ADDR' }))"
    exit 0
fi

WS=$(hyprctl clients -j | jq -r --arg a "$ADDR" \
  '[.[] | select(.address == $a)] | first | .workspace.name')

if [[ "$WS" == "$HIDE_WS" ]]; then
    # Restore: move back + focus
    hyprctl eval "hl.dispatch(hl.dsp.window.move({ workspace = '$(hyprctl activeworkspace -j | jq -r .name)', window = 'address:$ADDR', follow = false }))"
    hyprctl eval "hl.dispatch(hl.dsp.focus({ window = 'address:$ADDR' }))"
else
    # Hide
    hyprctl eval "hl.dispatch(hl.dsp.window.move({ workspace = '$HIDE_WS', window = 'address:$ADDR', follow = false }))"
fi   