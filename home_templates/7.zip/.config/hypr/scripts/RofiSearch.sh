#!/bin/bash
# Rofi theme and message
rofi_theme="$HOME/.config/rofi/config-search.rasi"
# Kill Rofi if already running before execution
if pgrep -x "rofi" >/dev/null; then
    pkill rofi
fi
query=$(echo "" | rofi -dmenu -config "$rofi_theme" -mesg "$msg")
status=$?
[ "$status" -eq 0 ] && hyprctl dispatch exec "[float] kitty opencode --prompt $(printf '%q' "$query")"
# [ "$status" -eq 0 ] && hyprctl dispatch exec "[float] kitty gemini -y -i $(printf '%q' "$query")"