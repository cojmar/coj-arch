#!/usr/bin/env bash

set -euo pipefail

STATE_FILE="${HYPR_SESSION_STATE_FILE:-$HOME/.config/hypr-session-restore.json}"
LEGACY_STATE_FILE="$HOME/.hypr-session-restore.json"
MODE="${1:-manual}"
WINDOW_MATCH_TIMEOUT="${HYPR_SESSION_MATCH_TIMEOUT:-15}"

discover_hypr_instance() {
  if [[ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]]; then
    printf '%s\n' "$HYPRLAND_INSTANCE_SIGNATURE"
    return 0
  fi

  local runtime_dir="/run/user/$(id -u)/hypr"
  local best_sig="" best_pid=-1 dir pid

  [[ -d "$runtime_dir" ]] || return 1

  for dir in "$runtime_dir"/*; do
    [[ -d "$dir" ]] || continue
    [[ -S "$dir/.socket.sock" ]] || continue
    [[ -f "$dir/hyprland.lock" ]] || continue
    pid="$(sed -n '1p' "$dir/hyprland.lock" 2>/dev/null || true)"
    [[ "$pid" =~ ^[0-9]+$ ]] || continue
    if (( pid > best_pid )); then
      best_pid=$pid
      best_sig="${dir##*/}"
    fi
  done

  [[ -n "$best_sig" ]] || return 1
  printf '%s\n' "$best_sig"
}

if [[ ! -f "$STATE_FILE" && -f "$LEGACY_STATE_FILE" ]]; then
  mkdir -p "$(dirname "$STATE_FILE")"
  cp "$LEGACY_STATE_FILE" "$STATE_FILE"
fi

[[ -f "$STATE_FILE" ]] || exit 0

HYPR_INSTANCE="$(discover_hypr_instance)"
RUNTIME_MARKER="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}/hypr-session-restored.${HYPR_INSTANCE}"

if [[ "$MODE" == "--startup" && -f "$RUNTIME_MARKER" ]]; then
  exit 0
fi

hypr() {
  hyprctl --instance "$HYPR_INSTANCE" "$@"
}

wait_for_hypr() {
  local i
  for i in {1..30}; do
    if hypr clients -j >/dev/null 2>&1; then
      return 0
    fi
    sleep 0.5
  done
  return 1
}

dispatch_best_effort() {
  local dispatcher="$1"
  local args="${2:-}"
  hypr dispatch "$dispatcher" "$args" >/dev/null 2>&1 || true
}

current_clients() {
  hypr clients -j
}

move_cursor_to_point() {
  local x="$1"
  local y="$2"
  dispatch_best_effort "movecursor" "$x $y"
}

find_new_window() {
  local before_file="$1"
  local saved_class="$2"
  local saved_initial_class="$3"
  local timeout="${4:-$WINDOW_MATCH_TIMEOUT}"
  local deadline=$((SECONDS + timeout))
  local clients address

  while (( SECONDS < deadline )); do
    clients="$(current_clients 2>/dev/null || true)"
    address="$(
      jq -r \
        --arg savedClass "$saved_class" \
        --arg savedInitialClass "$saved_initial_class" \
        --rawfile before "$before_file" '
        ($before | split("\n") | map(select(length > 0))) as $beforeList
        | [
            .[]
            | . as $client
            | select(($beforeList | index($client.address // "")) == null)
            | select(
                ($savedClass != "" and (($client.class // "") == $savedClass or ($client.initialClass // "") == $savedClass))
                or
                ($savedInitialClass != "" and (($client.class // "") == $savedInitialClass or ($client.initialClass // "") == $savedInitialClass))
              )
          ][0].address // empty
        ' <<<"$clients"
    )"
    if [[ -n "$address" ]]; then
      printf '%s\n' "$address"
      return 0
    fi
    sleep 0.4
  done

  return 1
}

restore_window() {
  local item_json="$1"
  local before_file cmdline saved_class saved_initial_class workspace monitor floating pinned fullscreen size_x size_y at_x at_y
  local address current_json current_floating current_pinned cursor_x cursor_y

  before_file="$(mktemp)"
  current_clients | jq -r '.[].address // empty' >"$before_file"

  cmdline="$(jq -r '.cmdline' <<<"$item_json")"
  saved_class="$(jq -r '.class // empty' <<<"$item_json")"
  saved_initial_class="$(jq -r '.initialClass // empty' <<<"$item_json")"
  workspace="$(jq -r '.workspace // empty' <<<"$item_json")"
  monitor="$(jq -r '.monitor // empty' <<<"$item_json")"
  floating="$(jq -r '.floating' <<<"$item_json")"
  pinned="$(jq -r '.pinned' <<<"$item_json")"
  fullscreen="$(jq -r '.fullscreen // 0' <<<"$item_json")"
  size_x="$(jq -r '.size[0] // 0' <<<"$item_json")"
  size_y="$(jq -r '.size[1] // 0' <<<"$item_json")"
  at_x="$(jq -r '.at[0] // 0' <<<"$item_json")"
  at_y="$(jq -r '.at[1] // 0' <<<"$item_json")"

  if [[ -n "$monitor" ]]; then
    dispatch_best_effort "focusmonitor" "$monitor"
    sleep 0.1
  fi
  move_cursor_to_point "$at_x" "$at_y"
  sleep 0.2

  bash -lc "exec $cmdline" >/dev/null 2>&1 &
  sleep 0.2

  if ! address="$(find_new_window "$before_file" "$saved_class" "$saved_initial_class" "$WINDOW_MATCH_TIMEOUT")"; then
    rm -f "$before_file"
    printf 'Timed out waiting for: %s\n' "$cmdline" >&2
    return 1
  fi

  rm -f "$before_file"

  if [[ -n "$workspace" && -n "$monitor" ]]; then
    dispatch_best_effort "focusmonitor" "$monitor"
    sleep 0.1
    dispatch_best_effort "moveworkspacetomonitor" "$workspace $monitor"
    sleep 0.15
  fi

  if [[ -n "$workspace" ]]; then
    dispatch_best_effort "workspace" "$workspace"
    sleep 0.1
    dispatch_best_effort "movetoworkspacesilent" "$workspace,address:$address"
    sleep 0.15
  fi

  dispatch_best_effort "focuswindow" "address:$address"
  sleep 0.15

  current_json="$(current_clients | jq -c --arg address "$address" '[.[] | select(.address == $address)][0] // {}')"
  current_floating="$(jq -r '.floating // false' <<<"$current_json")"
  current_pinned="$(jq -r '.pinned // false' <<<"$current_json")"

  if [[ "$floating" == "true" && "$current_floating" != "true" ]]; then
    dispatch_best_effort "togglefloating" "address:$address"
    sleep 0.15
  fi

  if [[ "$pinned" == "true" && "$current_pinned" != "true" ]]; then
    dispatch_best_effort "pin" "address:$address"
    sleep 0.15
  fi

  if [[ "$floating" == "true" ]]; then
    if (( size_x > 0 && size_y > 0 )); then
      dispatch_best_effort "resizewindowpixel" "exact $size_x $size_y,address:$address"
      sleep 0.15
    fi
    dispatch_best_effort "movewindowpixel" "exact $at_x $at_y,address:$address"
    sleep 0.15
  fi

  if (( fullscreen > 0 )); then
    dispatch_best_effort "fullscreen" "$fullscreen,address:$address"
  fi

  sleep 0.5
  current_json="$(current_clients | jq -c --arg address "$address" '[.[] | select(.address == $address)][0] // {}')"
  cursor_x="$(jq -r '((.at[0] // 0) + (((.size[0] // 0) / 2) | floor))' <<<"$current_json")"
  cursor_y="$(jq -r '((.at[1] // 0) + (((.size[1] // 0) / 2) | floor))' <<<"$current_json")"
  move_cursor_to_point "$cursor_x" "$cursor_y"
  sleep 0.1
  dispatch_best_effort "focuswindow" "address:$address"
}

wait_for_hypr

while IFS= read -r workspace_pair; do
  workspace_id="${workspace_pair%%	*}"
  workspace_monitor="${workspace_pair#*	}"
  [[ -n "$workspace_id" && -n "$workspace_monitor" ]] || continue
  dispatch_best_effort "moveworkspacetomonitor" "$workspace_id $workspace_monitor"
  sleep 0.1
done < <(jq -r '.workspaceMonitors | to_entries[] | "\(.key)\t\(.value)"' "$STATE_FILE")

while IFS= read -r item_json; do
  restore_window "$item_json" || true
  sleep 0.5
done < <(jq -c '.windows[]' "$STATE_FILE")

if [[ "$MODE" == "--startup" ]]; then
  : >"$RUNTIME_MARKER"
fi

printf 'Restored %s window definition(s) from %s\n' "$(jq '.windows | length' "$STATE_FILE")" "$STATE_FILE"
