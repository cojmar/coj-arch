#!/usr/bin/env bash

set -euo pipefail

STATE_FILE="${HYPR_SESSION_STATE_FILE:-$HOME/.config/hypr-session-restore.json}"

discover_hypr_instance() {
  if [[ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]]; then
    printf '%s\n' "$HYPRLAND_INSTANCE_SIGNATURE"
    return 0
  fi

  local runtime_dir="/run/user/$(id -u)/hypr"
  local best_sig="" best_pid=-1 dir pid

  [[ -d "$runtime_dir" ]] || return 1

  for dir in "$runtime_dir"/*; do
    [[ -d "$dir" ]] || continue
    [[ -S "$dir/.socket.sock" ]] || continue
    [[ -f "$dir/hyprland.lock" ]] || continue
    pid="$(sed -n '1p' "$dir/hyprland.lock" 2>/dev/null || true)"
    [[ "$pid" =~ ^[0-9]+$ ]] || continue
    if (( pid > best_pid )); then
      best_pid=$pid
      best_sig="${dir##*/}"
    fi
  done

  [[ -n "$best_sig" ]] || return 1
  printf '%s\n' "$best_sig"
}

HYPR_INSTANCE="$(discover_hypr_instance)"

hypr() {
  hyprctl --instance "$HYPR_INSTANCE" "$@"
}

shell_quote_cmdline() {
  local cmdline_file="$1"
  local arg quoted
  local -a args=()

  while IFS= read -r -d '' arg; do
    printf -v quoted '%q' "$arg"
    args+=("$quoted")
  done <"$cmdline_file"

  ((${#args[@]} > 0)) || return 1
  printf '%s\n' "${args[*]}"
}

tmpdir="$(mktemp -d)"
trap 'rm -rf "$tmpdir"' EXIT

clients_json="$tmpdir/clients.json"
monitors_json="$tmpdir/monitors.json"
workspaces_json="$tmpdir/workspaces.json"

hypr clients -j >"$clients_json"
hypr monitors -j >"$monitors_json"
hypr workspaces -j >"$workspaces_json"

cmd_map='{}'
while IFS= read -r pid; do
  [[ -n "$pid" ]] || continue
  [[ -r "/proc/$pid/cmdline" ]] || continue
  cmdline="$(shell_quote_cmdline "/proc/$pid/cmdline" || true)"
  [[ -n "$cmdline" ]] || continue
  cmd_map="$(jq -cn --argjson map "$cmd_map" --arg pid "$pid" --arg cmd "$cmdline" '$map + {($pid): $cmd}')"
done < <(jq -r '.[].pid // empty' "$clients_json" | awk '!seen[$0]++')

mkdir -p "$(dirname "$STATE_FILE")"

jq -n \
  --arg signature "$HYPR_INSTANCE" \
  --arg savedAt "$(date --iso-8601=seconds)" \
  --slurpfile clients "$clients_json" \
  --slurpfile monitors "$monitors_json" \
  --slurpfile workspaces "$workspaces_json" \
  --argjson cmdMap "$cmd_map" '
  def monitorById:
    reduce ($monitors[0][]) as $m ({}; .[($m.id | tostring)] = ($m.name // ""));
  def workspaceMonitor($monitorById):
    reduce ($workspaces[0][]) as $w ({};
      if $w.id == null then . else
        .[($w.id | tostring)] = (
          if ($w.monitor // "") != "" then
            $w.monitor
          elif $w.monitorID != null then
            ($monitorById[($w.monitorID | tostring)] // "")
          else
            ""
          end
        )
      end
    );
  (monitorById) as $monitorById
  | (workspaceMonitor($monitorById)) as $workspaceMonitors
  | {
      signature: $signature,
      savedAt: $savedAt,
      windows: [
        $clients[0][]
        | select((.workspace.id? // -999) >= 0)
        | select(.mapped // true)
        | select((.hidden // false) | not)
        | . as $client
        | ($cmdMap[($client.pid | tostring)] // "") as $cmdline
        | select($cmdline != "")
        | {
            cmdline: $cmdline,
            class: ($client.class // ""),
            initialClass: ($client.initialClass // ""),
            title: ($client.title // ""),
            initialTitle: ($client.initialTitle // ""),
            workspace: $client.workspace.id,
            workspaceName: ($client.workspace.name // ""),
            monitor: ($workspaceMonitors[($client.workspace.id | tostring)] // ""),
            floating: ($client.floating // false),
            fullscreen: ($client.fullscreen // 0),
            pinned: ($client.pinned // false),
            at: [($client.at[0] // 0), ($client.at[1] // 0)],
            size: [($client.size[0] // 0), ($client.size[1] // 0)]
          }
      ],
      workspaceMonitors: $workspaceMonitors
    }
  ' >"$STATE_FILE"

printf 'Saved %s window(s) to %s\n' "$(jq '.windows | length' "$STATE_FILE")" "$STATE_FILE"
