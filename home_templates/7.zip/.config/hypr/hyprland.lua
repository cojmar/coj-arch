-- JaKooLit Hyprland Lua configuration rebuilt from the original hyprland.conf.
local HOME = os.getenv("HOME")
local base = HOME .. "/.config/hypr/"

hl.env("TERMINAL", "kitty")
hl.window_rule({ float = true, center = true, match = { title = "btop" } })   
-- User defaults must be loaded before keybinds that reference $term and $files.
local modules = {
    "UserConfigs/01-UserDefaults.lua",
    "configs/Keybinds.lua",
    "configs/Startup_Apps.lua",
    "UserConfigs/Startup_Apps.lua",
    "configs/ENVariables.lua",
    "UserConfigs/ENVariables.lua",
    "configs/Laptops.lua",
    "UserConfigs/Laptops.lua",
    "UserConfigs/LaptopDisplay.lua",
    "configs/WindowRules.lua",
    "UserConfigs/WindowRules.lua",
    "configs/SystemSettings.lua",
    "UserConfigs/UserDecorations.lua",
    "UserConfigs/UserAnimations.lua",
    "UserConfigs/UserKeybinds.lua",
    "UserConfigs/UserSettings.lua",
    "monitors.lua",
    "workspaces.lua",
}

hl.on("hyprland.start", function()
    hl.exec_cmd(base .. "initial-boot.sh")
    hl.exec_cmd("/usr/lib/polkit-gnome/polkit-gnome-authentication-agent-1")
end)

for _, module in ipairs(modules) do
    dofile(base .. module)
end
