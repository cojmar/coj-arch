import "root:/services/"
import "root:/modules/common"
import "root:/modules/common/widgets"
import "root:/modules/common/functions/color_utils.js" as ColorUtils
import Qt5Compat.GraphicalEffects
import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Widgets
import Quickshell.Io
import Quickshell.Hyprland

Rectangle { // Window
    id: root
    property var windowData
    property var monitorData
    property var scale
    property var availableWorkspaceWidth
    property var availableWorkspaceHeight
    property bool restrictToWorkspace: true``
    property var sourceMonitor: HyprlandData.monitors.find(m => m.id === windowData?.monitor) || HyprlandData.monitors[0] || { scale: 1.0, x: 0, y: 0, reserved: [0,0,0,0] }
    property real monitorScaleFactor: sourceMonitor?.scale || 1.0
    property real targetScaleFactor: monitorData?.scale || monitorScaleFactor || 1.0
    property var focusedMonitor: Hyprland.focusedMonitor
    property real focusedMonitorScale: focusedMonitor?.scale || 1.0
    property real effectiveScale: root.scale * (
        ConfigOptions.overview.showAllMonitors 
            ? (focusedMonitorScale / monitorScaleFactor)  // Scale relative to focused monitor when showing all
            : (targetScaleFactor / monitorScaleFactor)    // Scale relative to target monitor normally
    )

    // Calculate position relative to source monitor
    property real relativeX: (windowData?.at[0] - sourceMonitor?.x - sourceMonitor?.reserved[0]) || 0
    property real relativeY: (windowData?.at[1] - sourceMonitor?.y - sourceMonitor?.reserved[1]) || 0

    // Scale position based on monitor differences
    property real initX: Math.max(relativeX * effectiveScale, 0) + xOffset
    property real initY: Math.max(relativeY * effectiveScale, 0) + yOffset
    property real xOffset: 0
    property real yOffset: 0
    
    // Scale window size based on monitor differences
    property var targetWindowWidth: (windowData?.size[0] || 0) * effectiveScale
    property var targetWindowHeight: (windowData?.size[1] || 0) * effectiveScale
    property bool hovered: false
    property bool pressed: false

    property var iconToWindowRatio: 0.35
    property var xwaylandIndicatorToIconRatio: 0.35
    property var iconToWindowRatioCompact: 0.6
    property var iconPath: Quickshell.iconPath(AppSearch.guessIcon(windowData?.class), "image-missing")
    property bool compactMode: Appearance.font.pixelSize.textSmall * 4 > targetWindowHeight || Appearance.font.pixelSize.textSmall * 4 > targetWindowWidth

    property bool indicateXWayland: (ConfigOptions.overview.showXwaylandIndicator && windowData?.xwayland) ?? false
    
    x: initX
    y: initY
    width: Math.min(windowData?.size[0] * root.scale, (restrictToWorkspace ? windowData?.size[0] : availableWorkspaceWidth - x + xOffset))
    height: Math.min(windowData?.size[1] * root.scale, (restrictToWorkspace ? windowData?.size[1] : availableWorkspaceHeight - y + yOffset))

    radius: Appearance.rounding.windowRounding * root.scale
    color: pressed ? Appearance.colors.colLayer2Active : hovered ? Appearance.colors.colLayer2Hover : Appearance.colors.colLayer2
    // border.color : ColorUtils.transparentize(Appearance.m3colors.m3outline, 0.9)
    border.color : ColorUtils.transparentize(Appearance.m3colors.m3borderPrimary, 0.4)
    border.pixelAligned : false
    border.width : 2

    Behavior on x {
        animation: Appearance.animation.elementMoveEnter.numberAnimation.createObject(this)
    }
    Behavior on y {
        animation: Appearance.animation.elementMoveEnter.numberAnimation.createObject(this)
    }
    Behavior on width {
        animation: Appearance.animation.elementMoveEnter.numberAnimation.createObject(this)
    }
    Behavior on height {
        animation: Appearance.animation.elementMoveEnter.numberAnimation.createObject(this)
    }

    ColumnLayout {
        anchors.verticalCenter: parent.verticalCenter
        anchors.left: parent.left
        anchors.right: parent.right
        spacing: Appearance.font.pixelSize.textSmall * 0.5

        IconImage {
            id: windowIcon
            Layout.alignment: Qt.AlignHCenter
            source: root.iconPath
            implicitSize: Math.min(targetWindowWidth, targetWindowHeight) * (root.compactMode ? root.iconToWindowRatioCompact : root.iconToWindowRatio)

            Behavior on implicitSize {
                animation: Appearance.animation.elementMoveEnter.numberAnimation.createObject(this)
            }
        }

        StyledText {
            Layout.leftMargin: 10
            Layout.rightMargin: 10
            visible: !compactMode
            Layout.fillWidth: true
            Layout.fillHeight: true
            horizontalAlignment: Text.AlignHCenter
            font.pixelSize: Appearance.font.pixelSize.textSmall
            font.italic: indicateXWayland ? true : false
            elide: Text.ElideRight
            text: windowData?.title ?? ""
        }
    }
}